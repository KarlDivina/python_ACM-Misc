import numpy as np

#1.	Write a code that creates an array with 5 elements filled with 1's. Display the output.

def arrOnes():
    arr = np.ones(5)
    print(arr)

arrOnes()